package com.example.cap.conn

class Json_Test(val test: String)