package com.example.cap.conn;

public class UserData {
    private String initWeight;

    public String getInitWeight() {
        return initWeight;
    }

    public void setInitWeight(String initWeight) {
        this.initWeight = initWeight;
    }
}
